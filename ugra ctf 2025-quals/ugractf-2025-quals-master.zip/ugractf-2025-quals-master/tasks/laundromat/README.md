# Прачечная

purplesyringa, reverse 400

> Ничего незаконного, просто деньги грязные.
> 
> *Добавлено 8 марта в 23:55:* Если при запуске приложения вы видите пустое окно, вы можете обойти баг рендеринга, установив переменную окружения `WEBKIT_DISABLE_COMPOSITING_MODE=1`.
>
> *laundromat*

[Write-up](WRITEUP.md)

# Laundromat

purplesyringa, reverse 400

> Nothing illegal, the money is just dirty.
> 
> *Added on March 8 at 23:55:* If the application shows an empty window, you can workaround the rendering bug by setting the environment variable `WEBKIT_DISABLE_COMPOSITING_MODE=1`.
>
> *laundromat*
