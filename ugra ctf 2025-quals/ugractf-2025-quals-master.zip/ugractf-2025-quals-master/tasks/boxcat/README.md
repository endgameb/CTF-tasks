# Коробкошка

purplesyringa, crypto 250

> Несмотря на то, что кошки все перевернули, на сайт продолжают заливать флаги. Разберитесь, в чем тут дело, и наградите непричастных.
> 
> *Добавлено 9 марта в 00:10:* Подсказка: Чтобы получить доступ к флагу, обязательно нужно ввести правильный пароль.
>
> *https://boxcat.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Boxcat

purplesyringa, crypto 250

> Despite the cats' best attempts to shuffle everything around, people aren't uploading cat
> pictures (there's still flags though, but that's not interesting to us). Find out why
> nothing's going on and put a start to it.
> 
> *Added on March 9 at 00:10:* Hint: To access the flag, you must enter the correct password.
>
> *https://boxcat.q.2025.ugractf.ru/token*
