# Санэпидемстанция

baksist, web 100

> ААА! У нас тараканы по офису бегают, срочно вызывайте дезинсектора!
> 
> *Сервер этой задачи запущен в отдельном контейнере для вашей команды.*
> 
> *https://pestcontrol.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Pest Control

baksist, web 100

> AAAH! There are cockroaches running around the office, call an exterminator ASAP!
> 
> *The server of this task is running in a container per team.*
> 
> *https://pestcontrol.q.2025.ugractf.ru/token*
