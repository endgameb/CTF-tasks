# Решётка

nsychev, crypto 100

> Нам нужна была крипта за 50, но у автора аллергия на квадратные решётки.
>
> *triangle.svg*

[Write-up](WRITEUP.md)

# Grille

nsychev, crypto 100

> We needed an easy crypto challenge, but the author is allergic to square grilles.
>
> *triangle.svg*
