# Конструктор

purplesyringa, web

> АГРОКЕКСТРОЙ ПРЕДСТАВЛЯЕТ
> 
>  КОНСТРУКТОР
> 
>  "ПОСТРОЙ САЙТ СВОИМИ РУКАМИ"
>
> *https://constructor.a.2025.ugractf.ru*

[Write-up](WRITEUP.md)

# Constructor

purplesyringa, web

> AGROKEKSTROY PRESENTS
> 
>  A CONSTRUCTOR
> 
>  "IKEA FOR WEBSITES"
>
> *https://constructor.a.2025.ugractf.ru*
