<?php
echo file_get_contents("/flag.txt");
