# PNG

purplesyringa, forensics 250

> Мы сделали то, что от нас прямо просили не делать, потому что мы не умеем читать. Теперь
>  ничего не работает, и если вы это не исправите, то винить мы в этом будем вас.
>
> *flag.png*

[Write-up](WRITEUP.md)

# PNG

purplesyringa, forensics 250

> We did something we were explicitly asked not to do, because we can't read. Now everything
>  doesn't work, and if you don't fix it, we'll blame you.
>
> *flag.png*
