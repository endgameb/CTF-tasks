# наизнанку

sylfn, forensics 100

> ...или же навыворот?
>
> *flag.exe*

[Write-up](WRITEUP.md)

# inside out

sylfn, forensics 100

> ...or outside in?
>
> *flag.exe*
