# Огни погони в городе

nsychev, osint

> В полицейском архиве всё перепутали! Осталось только видео, но место съёмки неизвестно. Найдите местоположение машины на моменте **0:02** с точностью до 50 метров.
> По обеим ссылкам загружен один и тот же видеоролик. Проверяющая система не содержит известных авторам уязвимостей — не пытайтесь её взломать.
>
> https://vkvideo.ru/video-161697856_456239017?list=ln-Mks9VaCGTOvfzxsk2m&t=2s  
> https://youtu.be/j0m2BBkO-wE?t=2s  
> *https://racelights.a.2025.ugractf.ru*

[Write-up](WRITEUP.md)

# City Race Lights

nsychev, osint

> The police archive is messed up! Only this video is left, but the location is unknown. Find the location of the car at **0:02** with an accuracy of 50 meters.
> Both links are to the same video. There are no intended vulnerabilities in the checking system, don’t try searching for them.
>
> https://vkvideo.ru/video-161697856_456239017?list=ln-Mks9VaCGTOvfzxsk2m&t=2s  
> https://youtu.be/j0m2BBkO-wE?t=2s  
> *https://racelights.a.2025.ugractf.ru*
