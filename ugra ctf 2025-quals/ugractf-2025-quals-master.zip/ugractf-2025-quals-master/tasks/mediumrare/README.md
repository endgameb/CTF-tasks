# Medium rare

purplesyringa, web 250

> После
> [фиаско на прошлом CTF](https://github.com/teamteamdev/ugractf-2024-school/tree/production/tasks/medium),
> когда мы выложили разбор прямо в составе задания, старых разработчиков уволили, наняли новых.
> Интерфейс сохранили, бекенд переписали с нуля. Теперь подобного повториться не должно.
> 
> *В этой задаче у каждой команды своя база данных.*
>
> *https://mediumrare.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Medium rare

purplesyringa, web 250

> After
> [the fiasco on the latest CTF](https://github.com/teamteamdev/ugractf-2024-school/tree/production/tasks/medium),
> when we published the write-up together with the problem statement, the old developers were laid off and new ones were hired.
> Interface remained the same, backend got a full rewrite. This surely won't happen again.
> 
> *Every team has their own database.*
> 
> *https://mediumrare.q.2025.ugractf.ru/token*
