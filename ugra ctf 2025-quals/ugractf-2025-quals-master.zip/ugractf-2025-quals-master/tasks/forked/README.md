# forked

sylfn, admin 150

> Дофоркались. Теперь нельзя.
>
> `nc forked.q.2025.ugractf.ru 3254`  
> Token: ...

[Write-up](WRITEUP.md)

# forked

sylfn, admin 150

> It is indeed forked.
>
> `nc forked.q.2025.ugractf.ru 3254`  
> Token: ...
