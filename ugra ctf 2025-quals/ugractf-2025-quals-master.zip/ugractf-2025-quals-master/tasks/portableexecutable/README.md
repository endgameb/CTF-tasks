# portable executable

sylfn, reverse 100

> Сомневаюсь.
>
> *flag.exe*

[Write-up](WRITEUP.md)

# portable executable

sylfn, reverse 100

> I doubt it.
>
> *flag.exe*
