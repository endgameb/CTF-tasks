# Котёнок!

sylfn, stegano

> ![](https://xkcd.ru/i/231_v1.png)
>
> [kitten.bmp](attachments/kitten.bmp)

[Write-up](WRITEUP.md)

# Kitty!

sylfn, stegano

> ![](https://imgs.xkcd.com/comics/cat_proximity.png)
>
> [kitten.bmp](attachments/kitten.bmp)
