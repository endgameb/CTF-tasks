# Кошкоробка

purplesyringa, misc 100

> На мой любимый сайт с кошками кто-то залил флаг. Разберитесь, в чем тут дело, и накажите невиновных.
> 
> *Добавлено 9 марта в 00:10:* Подсказка: Чтобы получить доступ к флагу, обязательно нужно ввести правильный пароль.
>
> *https://catbox.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Catbox

purplesyringa, misc 100

> Someone has uploaded a flag to my favorite cat site. Find out what's going on and put a stop to it.
> 
> *Added on March 9 at 00:10:* Hint: To access the flag, you must enter the correct password.
>
> *https://catbox.q.2025.ugractf.ru/token*
