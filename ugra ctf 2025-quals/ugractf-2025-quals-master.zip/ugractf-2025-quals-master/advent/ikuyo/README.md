# 行くよ

sylfn, misc

> — Мам, можно мне юникод?
> — У нас уже есть юникод дома.
> Юникод дома:
>
> *https://ikuyo.a.2025.ugractf.ru*

[Write-up](WRITEUP.md)

# 行くよ

sylfn, misc

> — Mom, can we have unicode?
> — We already have it at home.
> Unicode at home:
>
> *https://ikuyo.a.2025.ugractf.ru*
