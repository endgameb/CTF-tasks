# SecuSafe

rozetkinrobot, reverse 300

> Свою коммуникацию мы шифруем только инструментами, до которых не добрались спецслужбы. А до
>  чего они точно добраться не успели? Правильно: до приложения в самом низу поиска в Google
>  Play.
> 
> 
> 
> 
>  Всё бы хорошо, но теперь приложение обновилось, и старые данные перестали расшифровываться.
>  Всё, что есть и что мы помним — во вложениях. Поможете нам вернуть доступ к флагам?
> 
> 
> 
> 
> *Обновлено 8 марта в 18:33:* стоимость увеличена с 250 до 300.

[Write-up](WRITEUP.md)

# SecuSafe

rozetkinrobot, reverse 300

> We always encrypt our communications with the applications that intelligence services likely
>  haven't cracked. And what are they? That's right: the programs at the very bottom of Google
>  Play search results.
> 
> 
> 
> 
>  Unfortunately, we lost access to our data due to breaking changes in a recent update. We have
>  attached everything we think might be helpful. Can you help us get our flags back?
> 
> 
> 
> 
> *Updated on March 8 at 18:33:* awarded points changed from 250 to 300.
