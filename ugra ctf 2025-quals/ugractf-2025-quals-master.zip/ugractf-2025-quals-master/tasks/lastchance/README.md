# Последний шанс

sylfn, stegano 100

> — Ну вот я и дома. Наконец-то! Тяжелый выдался денёк...
>
> Я решил немного отдохнуть. Всё-таки сломанный лифт — это не шутки. «И что только этот IF значил?» — проскочило в моих мыслях.
>
> — Я еле держусь... Надо бы зайти и там уже расслабляться.
>
> Из кармана я достал от квартиры ключ, и стал открывать дверь.
>
> — Экая неприятность! Кто-то обчистил мою квартиру! Ну хоть самое главное — мой коврик настенный так и висит...
>
> *Чем же так ценно это разукрашенное полотно?*
>
> *scanned.png*

[Write-up](WRITEUP.md)

# The Last Chance

sylfn, stegano 100

> — Well, I'm home. Finally! It's been a long day...
>
> I decided to take a little rest. Broken elevator ain't joke, you know. “And what did that IF mean?” popped into my head.
>
> — I can barely cope... Shoulda enter my apt and unwind there.
>
> I pulled the key out of my pocket and opened the door.
>
> — Caramba! Someone cleaned my dwellers out! Well, at least the most precious thing, my carpet, still hangs on the wall.
>
> *Why is this canvas so valuable to us?*
>
> *scanned.png*
