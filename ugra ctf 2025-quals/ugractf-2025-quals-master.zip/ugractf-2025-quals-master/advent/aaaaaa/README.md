# AAAAAA

sylfn, crypto

> AAAAAA A ÃA̧AȂA̦ ǍÅÂÃĀÁȂ AAAAAAA!
>
> [Untitled.jpg](attachments/Untitled.jpg)

[Write-up](WRITEUP.md)
