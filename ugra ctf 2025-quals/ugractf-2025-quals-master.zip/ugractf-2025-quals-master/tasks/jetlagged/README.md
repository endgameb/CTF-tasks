# Но обещал вернуться

enhydra, osint 100

> Друг прислал эту фотографию, даже не подозревая, что по ней можно вычислить, где конкретно он в тот момент стоял. Разоблачите его.
> 
> Примечание: вашей команде доступно только 10 попыток ввода координат.
>
> [IMG_0799.jpg](attachments/IMG_0799.jpg)  
> *https://jetlagged.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Is the limit

enhydra, osint 100

> A friend of mine sent me this photo, not realizing that it could reveal where he was standing at that moment. Go impress him.
> 
> Keep in mind that your team only has 10 attempts to provide the coordinates.
>
> [IMG_0799.jpg](attachments/IMG_0799.jpg)  
> *https://jetlagged.q.2025.ugractf.ru/token*
