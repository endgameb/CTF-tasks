# Зоопарк

rozetkinrobot, web 150

> А вы когда-нибудь видели живых гоферов? Только сегодня все билеты в наш зоопарк по 100 рублей!
>
> *https://zoo.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Zoo

rozetkinrobot, web 150

> Have you ever seen gophers in person? Today all tickets to our zoo are 100 rubles only!
>
> *https://zoo.q.2025.ugractf.ru/token*
