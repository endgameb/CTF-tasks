# Брайль

purplesyringa, misc

> В 21 веке без доступности никуда, но как назло, у всех в нашем штате идеальное зрение, так
> что пришлось следовать советам нейронки. Вот теперь в решении тасок у всех будут одинаковые
> возможности!
>
> *https://dots.a.2025.ugractf.ru*

[Write-up](WRITEUP.md)

# Braille

purplesyringa, misc

> Accessibility is important, but alas -- everyone in our team has excellent eyesight, so we
> had to rely on advice from AI. Now everyone will have a chance to solve our tasks!
>
> *https://dots.a.2025.ugractf.ru*
