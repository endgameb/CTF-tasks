# Вещает, видимо

enhydra, forensics 150

> Мало нам [номерных радиостанций](https://ru.wikipedia.org/wiki/Номерная_радиостанция), стали появляться ещё и буквенные.
>
> *apparentcast.pcap*

[Write-up](WRITEUP.md)

# Casts, apparently

enhydra, forensics 150

> As if [number stations](https://en.wikipedia.org/wiki/Numbers_station) were not enough, now there are also ones with letters.
>
> *apparentcast.pcap*
