# Вращайте барабан!

nsychev, misc

> Теперь за игрой можно наблюдать прямо в режиме реального времени. Чудо, не правда ли?
> Назовёте флаг целиком?
>
> https://docs.google.com/spreadsheets/d/1Qnu-OppMEIIrz46-XATUv2rVIbXeptx32iDO9y0PsqE/edit

[Write-up](WRITEUP.md)

# Spin the Wheel!

nsychev, misc

> Now you can watch the game in real time. It's very fortunate, isn’t it?
> Can you call the flag?
>
> https://docs.google.com/spreadsheets/d/1Qnu-OppMEIIrz46-XATUv2rVIbXeptx32iDO9y0PsqE/edit
