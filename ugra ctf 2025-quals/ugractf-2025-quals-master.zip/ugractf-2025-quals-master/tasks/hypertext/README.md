# hypertext

sylfn, ctb 200

> HTTP — до боли простой протокол, и простенькие сервера пишутся очень легко. А безопасны ли они?
> 
> *Добавлено 9 марта в 00:10:* Подсказка: `[`
>
> *http://hypertext.q.2025.ugractf.ru:3253/token*

[Write-up](WRITEUP.md)

# hypertext

sylfn, ctb 200

> Implementing HTTP is a walk in the park, and simple servers are pretty straightforward. But what about their safety?
> 
> *Added on March 9 at 00:10:* Hint: `[`
>
> *http://hypertext.q.2025.ugractf.ru:3253/token*
