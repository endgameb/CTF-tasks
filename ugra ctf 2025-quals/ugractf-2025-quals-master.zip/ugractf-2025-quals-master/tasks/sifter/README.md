# Просеиватель

sylfn, reverse 400

> В УНИИИУ разработали супер-компьютер. (Время, правда, в УНИИИУ идёт чуть иначе, чем у нас, так что у вас может сложиться иное впечатление.) Мы получили доступ к его прототипу. Раскройте секреты уцуцуги вместе с нами!
>
> *https://sifter.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Sifter

sylfn, reverse 400

> URIRU has developed a supercomputer. (Time, however, passes differently in URIRU, so your mileage may vary.) We got our hands on its prototype. Let's decipher the secrets of ucucuga together!
>
> *https://sifter.q.2025.ugractf.ru/token*
