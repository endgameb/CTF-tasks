# Летнее чтение

purplesyringa, web 100

> Есть две вещи, которые все не читают, но боятся в этом признаться: летнее чтение и лицензионные соглашения. У нас тут та же ситуация.
>
> *https://summerreading.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Summer reading

purplesyringa, web 100

> There's two things people don't read but never admit to it: summer reading and licensing agreements. We've got a similar situation here.
>
> *https://summerreading.q.2025.ugractf.ru/token*
