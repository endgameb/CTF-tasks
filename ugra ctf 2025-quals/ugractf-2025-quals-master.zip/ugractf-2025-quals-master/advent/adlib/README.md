# ad lib

ksixty, stegano

> С юга планеты на частоте 666 кГц вещает некая сущность. О чём история этой сущности, и есть ли в сигнале что-то ещё?
>
> [ad_lib.mp3](attachments/ad_lib.mp3)

[Write-up](WRITEUP.md)

# ad lib

ksixty, stegano

> Some entity is broadcasting on 666 kHz from the south of the planet. What's its story and is there anything else in the signal?
>
> [ad_lib.mp3](attachments/ad_lib.mp3)
