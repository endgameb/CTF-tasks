# Телеграфный перевод

purplesyringa, crypto

> Мы перехватили телеграмму одного банка. Расшифруйте.
>
> [rsa.txt](attachments/rsa.txt)

[Write-up](WRITEUP.md)

# Wire transfer

purplesyringa, crypto

> We have intercepted a message from a certain bank. Decrypt it.
>
> [rsa.txt](attachments/rsa.txt)
