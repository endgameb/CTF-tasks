# Про, Макс

ksixty, reverse

> Помните Сельский клуб? Одно время было модно совещаться на важные темы. Но темы выросли и теперь актуальны по-настоящему закрытые клуба. Если в закрытый клуб случайно попадёт не свой человек, будет нехорошо. Поэтому попадаем не просто по приглашениям, а по настоящим Е-приглашениям, разработанным лучшими учёными и построенными лучшими строителями прямо на вашем ПК. Вот настоящий опытный образец такого Е-приглашения. Запускайте осторожно — мы ещё сами пока не поняли, что он исполняет.
>
> [VIP-KUPONCHIK.jl](attachments/VIP-KUPONCHIK.jl)

[Write-up](WRITEUP.md)

# Max is Pro

ksixty, reverse

> Remember The Village? It was the coolest thing ever, to discuss important topics in a closed space. Topics have grown since into really important matters that require truly exclusive clubs. All's waste, though, would such a club be infiltrated by a less-cooler person. Hence we're using not just invitations, but E-invitations, developed by top-notch scientists, built by best-of-class construction workers — right on your computer. Here's a real experimental sample of such an E-invitation. Be careful when touching the sample — we have no idea what it does.
>
> [VIP-KUPONCHIK.jl](attachments/VIP-KUPONCHIK.jl)
