# тишина

sylfn, ppc 200

> *звук сверчков*
>
> `nc q.2025.ugractf.ru 3252`  
> Token: ...

[Write-up](WRITEUP.md)

# silence

sylfn, ppc 200

> *crickets*
>
> `nc q.2025.ugractf.ru 3252`  
> Token: ...
