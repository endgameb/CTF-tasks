# /locate

purplesyringa, osint 200

> Найдите точные координаты **блока**, с которого сделана данная фотокарточка Северной Каролины.
> 
> Обратите внимание, что у вашей команды есть всего 7 попыток назвать координаты.
>
> [screenshot.png](attachments/screenshot.png)  
> *https://locate.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# /locate

purplesyringa, osint 200

> Find the exact coordiantes of the **block** that this picture of North Carolina was taken from.
> 
> Keep in mind that your team only has 7 attempts to call the coordinates.
>
> [screenshot.png](attachments/screenshot.png)  
> *https://locate.q.2025.ugractf.ru/token*
