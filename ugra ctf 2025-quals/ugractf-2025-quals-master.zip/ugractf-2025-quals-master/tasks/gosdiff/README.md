# Постановление

nsychev, ppc 150

> Из Департамента опять патч прислали. Да, опять не плейнтекстом. Они по-другому не умеют, что с них взять? Посмотришь на досуге?
>
> *Добавлено 9 марта в 16:15:* Комиссия по верификации фиксаций сообщила, что в пунктах, содержащих фразу «непосредственно после слов» в номере строки ошибка на единицу. Она исправляется однозначным образом. Эксплуатантам рекомендовано быть внимательнее при применении изменений.
>
> *patch.pdf*

[Write-up](WRITEUP.md)

# The Resolution

nsychev, ppc 150

> These clerks have just sent one more patch. Yes, it's not a plaintext again. They can’t do it right way. Could you take a look?
>
> *Added on March 9 at 16:15:* The patch verification committee found out that in paragraphs containing phrase “непосредственно после слов” the is a off-by-one mistake in the line number. It can be resolved unambiguously. Operators are advised to carefully apply these changes.
>
> *patch.pdf*
