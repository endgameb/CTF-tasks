# Yankbox

sylfn, ctb 100

> Как Pastebin, только проще
> 
> *Сервер этой задачи запущен в отдельном контейнере для вашей команды.*
> 
> *https://yankbox.q.2025.ugractf.ru/token*

[Write-up](WRITEUP.md)

# Yankbox

sylfn, ctb 100

> Like Pastebin, but easier
> 
> *Сервер этой задачи запущен в отдельном контейнере для вашей команды.*
> 
> *https://yankbox.q.2025.ugractf.ru/token*
